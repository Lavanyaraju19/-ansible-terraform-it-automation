# Readme to download patches from My Oracle Support

- Ported from https://github.com/oravirt/ansible-oracle
- Author: bartowl <github@bartowl.eu>
- Works with Ansible 2.10 and higher.

# Changes to the original version:
- Uses Patchid & Oracle Version instead of Patch filename.
